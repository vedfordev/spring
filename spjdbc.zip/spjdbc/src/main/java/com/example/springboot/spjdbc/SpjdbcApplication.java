package com.example.springboot.spjdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpjdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpjdbcApplication.class, args);
	}

}
